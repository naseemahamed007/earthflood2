MES FloodSense — Satellite & Flood Imagery Edition

FILES
- mes_floodsense.py: complete Streamlit application
- requirements.txt: Python dependencies

RUN ON WINDOWS
1. Install Python 3.10 or newer.
2. Extract this folder.
3. Open Command Prompt in this folder.
4. Run: pip install -r requirements.txt
5. Run: streamlit run mes_floodsense.py

The app needs an internet connection for Open-Meteo weather data, satellite tiles, and gallery images.
Gallery images are illustrative only. Satellite basemaps are not live flood-detection feeds.
