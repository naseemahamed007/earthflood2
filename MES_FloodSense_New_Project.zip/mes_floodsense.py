import streamlit as st
import requests
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
from urllib.parse import quote

# Optional satellite map support
try:
    import folium
    from streamlit_folium import st_folium
    FOLIUM_AVAILABLE = True
except ImportError:
    FOLIUM_AVAILABLE = False

# ============================================================
# MES FLOODSENSE — FLOOD & RAINFALL INTELLIGENCE
# ============================================================
st.set_page_config(
    page_title="MES FloodSense",
    page_icon="🌊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Remote imagery is illustrative context, not evidence of current flooding.
# The app also offers a live satellite basemap centered on the searched location.
FLOOD_IMAGE_URLS = [
    {
        "title": "Urban flooding",
        "description": "Illustrative photograph of floodwater in a built-up area.",
        "url": "https://images.unsplash.com/photo-1547683905-f686c993aae5?auto=format&fit=crop&w=1400&q=85",
    },
    {
        "title": "Heavy rainfall",
        "description": "Illustrative storm and rainfall conditions.",
        "url": "https://images.unsplash.com/photo-1519692933481-e162a57d6721?auto=format&fit=crop&w=1400&q=85",
    },
    {
        "title": "Flooded landscape",
        "description": "Illustrative high-water landscape; not a live observation.",
        "url": "https://images.unsplash.com/photo-1433086966358-54859d0ed716?auto=format&fit=crop&w=1400&q=85",
    },
]

st.markdown("""
<style>
.stApp {
    background:
        radial-gradient(ellipse at 5% 0%, rgba(25,62,112,.70) 0%, transparent 35%),
        linear-gradient(140deg, #071525 0%, #101b36 55%, #202044 100%);
    color: #f2f6ff;
}
.block-container {max-width: 1480px; padding-top: 1.35rem; padding-bottom: 3rem;}
h1,h2,h3,p,label {color:#f2f6ff;}
.hero {
    padding: 34px; border-radius: 26px;
    background: linear-gradient(115deg, #087eaa, #4f46e5 60%, #9333ea);
    border: 1px solid #7794ff; box-shadow: 0 15px 40px #0004; margin-bottom: 24px;
}
.hero-tag {color:#a7f3d0; font-size:12px; font-weight:800; letter-spacing:3px;}
.hero h1 {font-size:clamp(30px,4vw,48px); margin:10px 0;}
.hero p {color:#edf5ff; font-size:16px;}
.section-card {
    background:linear-gradient(145deg,rgba(20,41,68,.92),rgba(32,41,74,.88));
    border:1px solid #385477; border-radius:18px; padding:18px; margin-bottom:12px;
}
div[data-testid="stMetric"] {
    background:linear-gradient(145deg,#142944,#20294a);
    border:1px solid #385477; border-radius:18px; padding:18px; box-shadow:0 8px 25px #0002;
}
div[data-testid="stMetricLabel"] {color:#c2d3ee;}
div[data-testid="stMetricValue"] {color:#67e8f9; font-weight:800;}
.stButton>button,.stDownloadButton>button {
    border-radius:12px; min-height:44px; font-weight:700; border:1px solid #67e8f9;
}
section[data-testid="stSidebar"] {background:linear-gradient(180deg,#09172b,#172544);}
.footer {padding:22px; margin-top:28px; border-top:1px solid #34445f; text-align:center; color:#b5c7e5;}
.small-note {font-size:12px; color:#b5c7e5;}
</style>
""", unsafe_allow_html=True)


@st.cache_data(ttl=600, show_spinner=False)
def get_weather(city: str, forecast_days: int):
    """Fetch geocoding and forecast data from Open-Meteo."""
    geo_response = requests.get(
        "https://geocoding-api.open-meteo.com/v1/search",
        params={"name": city, "count": 1, "language": "en", "format": "json"},
        timeout=20,
    )
    geo_response.raise_for_status()
    places = geo_response.json().get("results", [])
    if not places:
        return None

    place = places[0]
    weather_response = requests.get(
        "https://api.open-meteo.com/v1/forecast",
        params={
            "latitude": place["latitude"],
            "longitude": place["longitude"],
            "current": (
                "temperature_2m,relative_humidity_2m,apparent_temperature,"
                "precipitation,rain,showers,weather_code,wind_speed_10m"
            ),
            "hourly": (
                "precipitation,precipitation_probability,temperature_2m,wind_speed_10m"
            ),
            "forecast_days": forecast_days,
            "timezone": "auto",
        },
        timeout=25,
    )
    weather_response.raise_for_status()
    return place, weather_response.json()


def weather_description(code):
    """Readable summary for common WMO weather codes."""
    if code is None:
        return "Not available"
    try:
        code = int(code)
    except (TypeError, ValueError):
        return "Not available"
    if code == 0:
        return "Clear sky"
    if code in (1, 2, 3):
        return "Mainly clear / partly cloudy / overcast"
    if code in (45, 48):
        return "Fog"
    if code in (51, 53, 55, 56, 57):
        return "Drizzle"
    if code in (61, 63, 65, 66, 67):
        return "Rain"
    if code in (71, 73, 75, 77):
        return "Snow / snow grains"
    if code in (80, 81, 82):
        return "Rain showers"
    if code in (85, 86):
        return "Snow showers"
    if code in (95, 96, 99):
        return "Thunderstorm"
    return f"Weather code {code}"


# ------------------------------ SIDEBAR ------------------------------
with st.sidebar:
    st.markdown("## 🌊 MES FloodSense")
    st.caption("Environmental intelligence dashboard")
    st.divider()
    city = st.text_input("📍 Search a city or town", value="Chennai", placeholder="For example, Chennai")
    forecast_days = st.selectbox(
        "📅 Forecast duration",
        [1, 3, 7],
        index=1,
        format_func=lambda n: f"{n} day" if n == 1 else f"{n} days",
    )
    if st.button("🔄 Refresh weather data", use_container_width=True):
        get_weather.clear()
        st.rerun()
    st.divider()
    st.markdown("### 📡 Data source")
    st.caption("Open-Meteo public weather API")
    st.caption("Forecast and current weather estimates")
    st.caption("Cached for up to 10 minutes")
    st.divider()
    st.markdown("### 🛰️ Satellite layer")
    st.caption("Satellite tiles are supplied by Esri World Imagery and require an internet connection.")
    st.divider()
    st.markdown("### ⚠️ Important")
    st.caption("Forecasts and illustrative images cannot confirm flooding at street level. Follow official warnings.")

# ------------------------------ HEADER ------------------------------
st.markdown("""
<div class="hero">
  <div class="hero-tag">MES • ENVIRONMENTAL RESEARCH</div>
  <h1>🌊 MES FloodSense</h1>
  <p>Explore rainfall patterns, weather conditions, satellite imagery and forecasts through an interactive environmental monitoring dashboard.</p>
  <div>🌦️ Weather intelligence &nbsp; • &nbsp; 📊 Interactive analytics &nbsp; • &nbsp; 🛰️ Satellite explorer</div>
</div>
""", unsafe_allow_html=True)
st.info("MES FloodSense is a research prototype. It displays weather forecasts and contextual imagery, not verified flood observations or an official flood warning.")

# ------------------------------ LOAD DATA ------------------------------
if not city.strip():
    st.warning("Enter a city or town in the sidebar.")
    st.stop()

try:
    with st.spinner("🌐 Loading the latest available weather data..."):
        result = get_weather(city.strip(), forecast_days)
    if result is None:
        st.error("Location not found. Check the spelling or try another city.")
        st.stop()
    place, weather = result
    current = weather.get("current", {})
    hourly = weather.get("hourly", {})
    if not current or not hourly or not hourly.get("time"):
        st.error("The weather service returned incomplete data.")
        st.stop()

    df = pd.DataFrame({
        "Time": pd.to_datetime(hourly["time"]),
        "Rainfall (mm)": hourly["precipitation"],
        "Rain probability (%)": hourly["precipitation_probability"],
        "Temperature (°C)": hourly["temperature_2m"],
        "Wind speed (km/h)": hourly["wind_speed_10m"],
    })
except requests.RequestException as exc:
    st.error(f"Unable to connect to the weather service. Check your connection and refresh. Details: {exc}")
    st.stop()
except (KeyError, ValueError, TypeError) as exc:
    st.error(f"The weather service returned unexpected data. Please try again. Details: {exc}")
    st.stop()

# ------------------------------ LOCATION ------------------------------
st.markdown(f"### 📍 {place['name']}, {place.get('admin1', '')}, {place.get('country', '')}")
st.caption(
    f"Weather API timestamp: {current.get('time', 'Not supplied')} · "
    f"Timezone: {weather.get('timezone', 'Not supplied')}"
)
st.caption("The timestamp is supplied by the weather service and does not guarantee a live physical sensor measurement.")

# ------------------------------ CURRENT CONDITIONS ------------------------------
st.markdown("### ⚡ Current weather estimates")
c1, c2, c3, c4 = st.columns(4)
c1.metric("🌡️ Temperature", f"{current.get('temperature_2m', '—')} °C")
c2.metric("💧 Humidity", f"{current.get('relative_humidity_2m', '—')}%")
c3.metric("🌧️ Precipitation", f"{current.get('precipitation', '—')} mm")
c4.metric("💨 Wind speed", f"{current.get('wind_speed_10m', '—')} km/h")
st.markdown(
    f'<div class="section-card"> <b>Conditions:</b> {weather_description(current.get("weather_code"))} '
    f'&nbsp; · &nbsp; <b>Feels like:</b> {current.get("apparent_temperature", "—")} °C</div>',
    unsafe_allow_html=True,
)

# ------------------------------ FORECAST SUMMARY ------------------------------
st.markdown("### 📈 Forecast overview")
s1, s2, s3 = st.columns(3)
s1.metric("Forecast duration", f"{forecast_days} day" if forecast_days == 1 else f"{forecast_days} days")
s2.metric("Total forecast rainfall", f"{df['Rainfall (mm)'].sum():.1f} mm")
s3.metric("Peak hourly rainfall", f"{df['Rainfall (mm)'].max():.1f} mm")
st.caption("Forecast rainfall is the sum of hourly precipitation values, not a flood-risk score.")

# ------------------------------ CHART EXPLORER ------------------------------
st.markdown("### 📊 Interactive weather explorer")
chart_choice = st.selectbox(
    "Choose a data layer",
    ["Rainfall (mm)", "Rain probability (%)", "Temperature (°C)", "Wind speed (km/h)"],
)
max_hours = len(df)
hours_to_show = st.slider(
    "Choose how many forecast hours to display",
    min_value=1,
    max_value=max_hours,
    value=min(48, max_hours),
    step=1,
)
chart_df = df.head(hours_to_show)
chart_colours = {
    "Rainfall (mm)": "#22d3ee",
    "Rain probability (%)": "#a78bfa",
    "Temperature (°C)": "#fb923c",
    "Wind speed (km/h)": "#4ade80",
}
fig = px.area(
    chart_df, x="Time", y=chart_choice, title=f"{chart_choice} forecast",
    template="plotly_dark", color_discrete_sequence=[chart_colours[chart_choice]],
)
fig.update_layout(
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(12,25,48,0.6)",
    font_color="#eef6ff", title_font_size=22, margin=dict(l=15, r=15, t=60, b=15),
    hovermode="x unified",
)
fig.update_traces(line=dict(width=3), fillcolor="rgba(34,211,238,0.16)")
if chart_choice == "Rain probability (%)":
    fig.update_yaxes(range=[0, 100])
st.plotly_chart(fig, use_container_width=True)

# ------------------------------ SATELLITE MAP ------------------------------
st.markdown("## 🛰️ Satellite & location explorer")
st.markdown(
    "Explore the searched location on satellite imagery. Satellite tiles are visual context only; "
    "they do not identify current floodwater automatically."
)
map_col, map_info = st.columns([1.65, 1], gap="large")
with map_col:
    if FOLIUM_AVAILABLE:
        sat_map = folium.Map(
            location=[place["latitude"], place["longitude"]],
            zoom_start=11,
            tiles=None,
            control_scale=True,
        )
        folium.TileLayer(
            tiles="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
            attr="Tiles © Esri — Sources: Esri, Maxar, Earthstar Geographics, and the GIS User Community",
            name="Satellite imagery",
            overlay=False,
            control=True,
        ).add_to(sat_map)
        folium.TileLayer(
            tiles="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
            attr="© OpenStreetMap contributors © CARTO",
            name="Dark street map",
            overlay=False,
            control=True,
        ).add_to(sat_map)
        folium.Marker(
            [place["latitude"], place["longitude"]],
            tooltip=f"{place['name']} — searched location",
            popup=f"{place['name']}, {place.get('country', '')}",
            icon=folium.Icon(color="blue", icon="info-sign"),
        ).add_to(sat_map)
        folium.LayerControl(collapsed=False).add_to(sat_map)
        st_folium(sat_map, use_container_width=True, height=480, returned_objects=[])
    else:
        st.warning("Install streamlit-folium and folium to enable the satellite map. The standard map below is still available.")
        st.map(pd.DataFrame({"latitude": [place["latitude"]], "longitude": [place["longitude"]]}))
with map_info:
    st.markdown("### 📍 Selected location")
    st.metric("Latitude", f"{place['latitude']:.4f}°")
    st.metric("Longitude", f"{place['longitude']:.4f}°")
    st.markdown(
        '<div class="section-card"><b>Satellite view</b><br>Use the map layer selector to switch between satellite imagery and a dark street map. Zoom in to inspect geography and nearby waterways.</div>',
        unsafe_allow_html=True,
    )
    st.caption("Imagery dates and update frequency vary by provider. A satellite basemap is not a live flood-detection feed.")

# ------------------------------ FLOOD IMAGE GALLERY ------------------------------
st.markdown("## 🌧️ Flood & rainfall visual gallery")
st.caption("These remote photographs are illustrative examples, not verified photographs of the selected city or current conditions.")
image_cols = st.columns(3)
for col, item in zip(image_cols, FLOOD_IMAGE_URLS):
    with col:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        try:
            st.image(item["url"], use_container_width=True, caption=item["title"])
            st.write(item["description"])
        except Exception:
            st.warning(f"Could not load the {item['title'].lower()} image. Check your internet connection.")
        st.markdown("</div>", unsafe_allow_html=True)

# ------------------------------ TABS ------------------------------
map_tab, data_tab, about_tab = st.tabs(["🗺️ Location map", "📄 Forecast data", "ℹ️ About MES FloodSense"])
with map_tab:
    st.markdown("#### 🌍 Selected monitoring location")
    st.map(pd.DataFrame({"latitude": [place["latitude"]], "longitude": [place["longitude"]]}))
    st.caption("This map marks the searched city. It does not show verified flood boundaries or street-level water levels.")
with data_tab:
    st.markdown("#### Hourly forecast data")
    st.dataframe(chart_df, use_container_width=True, hide_index=True)
    st.download_button(
        "⬇️ Download forecast data (CSV)",
        data=chart_df.to_csv(index=False).encode("utf-8"),
        file_name="MES_FloodSense_forecast.csv",
        mime="text/csv",
        use_container_width=True,
    )
with about_tab:
    st.markdown("#### 🌍 About the project")
    st.write("MES FloodSense is a software research prototype for exploring weather forecasts, rainfall information, satellite basemaps and contextual flood imagery.")
    st.write("**Weather provider:** Open-Meteo")
    st.write("**Satellite imagery:** Esri World Imagery")
    st.write("**Technology:** Python, Streamlit, Pandas, Plotly, Folium")
    st.write("**Cost:** Open-Meteo forecast access does not require a paid API key.")
    st.warning("This version does not include verified river gauges, street-level flood sensors, automatic flood-image classification or an official flood-warning feed.")

st.markdown("""
<div class="footer">
  <strong>🌊 MES FloodSense</strong><br>
  Environmental awareness through data.<br><br>
  Research prototype · Not an official flood-warning system
</div>
""", unsafe_allow_html=True)
